<section class="page-section-ptb">
    <div class="container">
    <div class="row mt-60">
        <div class="col-lg-12">
           <h4 class="mb-30">Team overlay</h4>
        </div>
        <div class="col-lg-3 col-sm-6 sm-mb-30">
           <div class="team team-hover team-overlay text-center">
              <div class="team-photo">
                <img class="img-fluid mx-auto" src="images/team/01.jpg" alt=""> 
              </div>    
              <div class="team-description"> 
                <div class="team-info"> 
                     <h5 class="text-white"> <a href="team-single.html"> Martin Smith</a></h5>
                     <span class="text-white">CEO</span>
                </div>
               </div>
           </div>
          </div>
          <div class="col-lg-3 col-sm-6 sm-mb-30">
           <div class="team team-hover team-overlay text-center">
              <div class="team-photo">
                <img class="img-fluid mx-auto" src="images/team/02.jpg" alt=""> 
              </div>    
              <div class="team-description"> 
                <div class="team-info"> 
                     <h5 class="text-white"> <a href="team-single.html"> Paul Flavius </a></h5>
                     <span class="text-white">Design</span>
                </div>
               </div>
           </div>
          </div>
          <div class="col-lg-3 col-sm-6 xs-mb-30">
           <div class="team team-hover team-overlay text-center">
              <div class="team-photo">
                <img class="img-fluid mx-auto" src="images/team/06.jpg" alt=""> 
              </div>    
              <div class="team-description"> 
                <div class="team-info"> 
                     <h5 class="text-white"> <a href="team-single.html">Anne Smith</a></h5>
                     <span class="text-white">Community</span>
                </div>
               </div>
           </div>
          </div>  
          <div class="col-lg-3 col-sm-6">
           <div class="team team-hover team-overlay text-center">
              <div class="team-photo">
                <img class="img-fluid mx-auto" src="images/team/04.jpg" alt=""> 
              </div>    
              <div class="team-description"> 
                <div class="team-info"> 
                     <h5 class="text-white"><a href="team-single.html">Sara Lisbon</a></h5>
                     <span class="text-white">Graphic Designer</span>
                </div>
               </div>
           </div>
          </div>
       </div>
    </div>
</section>