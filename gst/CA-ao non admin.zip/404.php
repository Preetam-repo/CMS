<link rel="stylesheet" type="text/css" href="demo-specialty-pages/error-06/css/error-06.css" />
 
<div class="wrapper">

<div class="height-100vh parallax" style="background-image: url(demo-specialty-pages/error-06/images/01.jpg);">

<!--=================================
 preloader -->
 
<div id="pre-loader">
    <img src="images/pre-loader/loader-01.svg" alt="">
</div>

<!--=================================
 preloader -->


<!--=================================
 error -->

 <div class="error-06 error-middle page-section-ptb">
   <div class="container">
    <div class="row justify-content-center">
     <div class="col-lg-6">
       <h1 class="text-white">404</h1>
       <h2 class="text-white">Page not found!</h2>
       <p class="text-white"> Don't worry, sometimes it happens even for the best of us :)</p>
        <div class="widget-search mt-30">
          <i class="fa fa-search"></i>
          <input type="search" class="form-control" placeholder="Search....">
        </div>
        <a class="button white button-border mt-30" href="index-01.html">Back to home</a>
     </div>
   </div>
   </div>
  </div>
 </div>
</div>