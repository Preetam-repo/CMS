<section class="service white-bg page-section-ptb">
  <div class="container">
    <div class="row justify-content-center">
       <div class="col-lg-8">
            <div class="section-title text-center">
            <h6>How it works? </h6>
            <h2 class="title-effect">Provide excellent service</h2>
            <p>We are dedicated to providing you with the best experience possible.</p>
          </div>
      </div>
    </div>
    <div class="row">
         <div class="col-lg-4 col-md-4">
            <div class="mb-30">
              <h1>01<span class="theme-color">.</span></h1>
              <h3>We have magic</h3>
              <p>I truly believe Augustine’s words are true and if you look at history you know it is true. There are many people in the world with amazing. </p>
              <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
            </div>
         </div>
         <div class="col-lg-4 col-md-4">
            <div class="mb-30">
              <h1>02<span class="theme-color">.</span></h1>
              <h3>We're Friendly</h3>
              <p>The first thing to remember about success is that it is a process – nothing more, nothing less. There is really no magic to it and it’s not.</p>
              <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
            </div>
         </div>
         <div class="col-lg-4 col-md-4">
            <div class="text-left">
              <h1>03<span class="theme-color">.</span></h1>
              <h3>We’re award winner</h3>
              <p>There are basically six key areas to higher achievement. Some people will tell you there are four while others may tell you there are eight. </p>
              <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
            </div>
         </div>
      </div>
   </div>
 </section>