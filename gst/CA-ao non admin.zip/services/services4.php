<section class="about page-section-ptb">
  <div class="container">
    <div class="row justify-content-center">
       <div class="col-lg-8 col-md-8">
       <div class="section-title text-center">
            <h6>We're Good At</h6>
            <h2 class="title-effect">Our Services </h2>
            <p>Webster is Truly multi-purpose & outstanding template with Many Features.</p>
          </div>
      </div>
    </div>
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="feature-text round theme-icon text-center xs-mb-30">
            <div class="feature-icon">
              <span aria-hidden="true" class="ti-layers-alt theme-color"></span>
            </div>
              <div class="feature-info">
              <h4 class="pb-10">Unlimited layouts</h4>
              <p>Nesciunt in accusamus necessitatibus modi adipisci officia dolor sit amet consectetur adipisicing elit conseqt quibusdam </p>
          </div>
         </div> 
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="feature-text round theme-icon text-center xs-mb-30">
            <div class="feature-icon">
              <span aria-hidden="true" class="ti-shield theme-color"></span>
            </div>
              <div class="feature-info">
              <h4 class="pb-10">Powerful Performance</h4>
              <p>Vero quod conseqt quibusdam sed quia nesciunt in accusamus necessitatibus modi adipisci officia dolor consectetur adipisicing elit.</p>
          </div>
         </div> 
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="feature-text round theme-icon text-center">
            <div class="feature-icon">
              <span aria-hidden="true" class="ti-image theme-color"></span>
            </div>
              <div class="feature-info">
              <h4 class="pb-10">Revolution Slider</h4>
              <p>Modi adipisci officia dolor sit amet consectetur adipisicing elit Vero quod conseqt quibusdam sed quia nesciunt in accusamus</p>
          </div>
         </div> 
        </div>
     </div>
  </div>
</section>