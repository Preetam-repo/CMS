<section class="page-section-ptb parallax" data-jarallax='{"speed": 1}' style="background-image: url(images/bg/28.jpg);">
  <div class="container">
    <div class="row">
      <div class="col-6">
        <div class="section-title">
          <h6>Our services</h6>
          <h3>A farmer hears tales of diamonds and begins.</h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="feature-text left-icon">
            <div class="feature-icon">
            <span class="ti-layers-alt"></span>
          </div>
          <div class="feature-info">
            <h5>Bootstrap 4 base template</h5>
            <p>Consectetur dolor sit conseqt quibusdam, enim expedita sed quia nesciunt</p>
          </div>
        </div>
        <div class="feature-text left-icon mt-30">
             <div class="feature-icon">
              <span class="ti-mouse"></span>
            </div>
            <div class="feature-info">
              <h5>Premium plugin included</h5>
              <p>Enim expedita sed quia nesciunt, dolor sit consectetur conseqt</p>
            </div>
          </div>
            <div class="feature-text left-icon mt-30">
             <div class="feature-icon">
              <span class="fa fa-paint-brush"></span>
            </div>
            <div class="feature-info">
              <h5>Unique & Clean  </h5>
              <p>Responsive and Flexible layout. This allows the web page to stretch and contract relative to the user's screen.</p>
            </div>
          </div>
          <div class="feature-text left-icon mt-30">
             <div class="feature-icon">
              <span class="ti-mouse"></span>
            </div>
            <div class="feature-info">
              <h5>Premium plugin included</h5>
              <p>Enim expedita sed quia nesciunt, dolor sit consectetur conseqt</p>
            </div>
          </div>
      </div>
    </div>    
  </div>
</section>