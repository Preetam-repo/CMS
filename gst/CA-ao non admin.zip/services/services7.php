<section class="our-services page-section-ptb gray-bg">
  <div class="container">
     <div class="row">
       <div class="col-lg-12 col-md-12">
          <div class="section-title text-center">
            <h6>We're Good At</h6>
              <h2 class="title-effect">Our Services </h2>
            </div>
         </div>
       </div>
         <div class="row">
          <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center mb-30 white-bg">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-layers-alt"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">Many Style Available</h4>
              <p>Quibusdam, sed quia nesciunt dolor sit amet, consectetur adipisicing elit. Vero quod conseqt </p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
         <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center mb-30 white-bg">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-image"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">Revolution Slider</h4>
             <p>Sed quia nesciunt dolor sit amet, consectetur adipisicing elit. Vero quod conseqt quibusdam</p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center mb-30 white-bg">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-heart"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">Blog Options</h4>
             <p>Quibusdam sed quia nesciunt Vero dolor conseqt sit amet, consectetur vero adipisicing elit. Vero quod conseqt </p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
       </div>
       <div class="row">
    <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center white-bg mb-30">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-panel"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">Easy to Customize</h4>
             <p>Adipisicing elit. Vero quod conseqt quibusdam, sed quia nesciunt dolor sit amet, consectetur </p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
           <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center white-bg mb-30">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-shield"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">Powerful Performance</h4>
             <p>Quod conseqt quibusdam sed quia nesciunt dolor sit amet, consectetur adipisicing elit vero </p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
            <div class="col-lg-4 col-md-4">
          <div class="feature-text box-shadow text-center white-bg mb-30">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-headphone"></span>
            </div>
           <div class="fature-info"> 
             <h4 class="text-back pt-20 pb-10">24/7 Customer support</h4>
              <p>Consectetur adipisicing elit. Vero quod conseqt quibusdam, sed quia nesciunt dolor sit amet</p>
             <a class="button mt-20" href="#">read more</a>
           </div>
          </div>
        </div>
       </div>
  </div>
</section>