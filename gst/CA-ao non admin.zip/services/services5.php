<section id="services" class="page-section-ptb gray-bg position-relative">
  <div class="container-fluid">
   <div class="row">
     <div class="col-md-12">
         <div class="section-title text-center">
            <h6>We're Good At </h6>
            <h2 class="title-effect">Our Services </h2>
            <p>I have more than 9 years of experience in the field of Graphic/ E-Learning/Web Designing.</p>
         </div>
     </div>
   </div>
   <div class="row">
     <div class="col-lg-3 col-sm-6">       
          <div class="feature-text left-icon mb-30">
             <div class="feature-icon">
              <span class="ti-palette theme-color" aria-hidden="true"></span>
              </div>
            <div class="feature-info">
              <h5 class="mt-20">Web Design </h5>
               <p>Responsive Lorem Ipsum used since the 1500s is reproduced below for those. </p>
              <a class="button icon-color" href="#">Read more <i class="fa fa-angle-right"></i></a>
           </div>
          </div> 
      </div>
     <div class="col-lg-3 col-sm-6">
       <div class="feature-text left-icon mb-30">
         <div class="feature-icon">
          <span class="ti-camera theme-color" aria-hidden="true"></span>
          </div>
        <div class="feature-info">
          <h5 class="mt-20">Photography </h5>
           <p>Reproduced below for those <span class="theme-color" data-toggle="tooltip" data-placement="top" title="" data-original-title="Tooltip on top">responsive</span>  Lorem Ipsum used since the 1500s is. </p>
          <a class="button icon-color" href="#">Read more <i class="fa fa-angle-right"></i></a>
       </div>
      </div> 
     </div>
     <div class="col-lg-3 col-sm-6">
       <div class="feature-text left-icon mb-30">
           <div class="feature-icon">
            <span class="ti-layers theme-color" aria-hidden="true"></span>
            </div>
          <div class="feature-info">
            <h5 class="mt-20">Creativity </h5>
             <p>The 1500s is reproduced responsive Lorem Ipsum used since below for those. </p>
            <a class="button icon-color" href="#">Read more <i class="fa fa-angle-right"></i></a>
         </div>
        </div> 
     </div>
      <div class="col-lg-3 col-sm-6">
       <div class="feature-text left-icon mb-30">
           <div class="feature-icon">
            <span class="ti-desktop theme-color" aria-hidden="true"></span>
            </div>
          <div class="feature-info">
            <h5 class="mt-20">Advertising</h5>
             <p>Since the 1500s responsive Lorem Ipsum used is reproduced below for those. </p>
            <a class="button icon-color" href="#">Read more <i class="fa fa-angle-right"></i></a>
         </div>
        </div> 
     </div>
   </div>
 </div>
</section>