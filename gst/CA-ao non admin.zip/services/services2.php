<?php
$services = $resp->services;
$serviceStyle = json_decode($sectionStyle->services);
?>
<section class="our-service page-section-ptb">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12">
             <div class="section-title text-center">
              <h6><?php echo $serviceStyle->top_tag_line; ?></h6>
              <h2 class="title-effect"><?php echo $serviceStyle->title; ?></h2>
            </div>
         </div>
      </div>
       <div class="row justify-content-center">
         <div class="col-md-10">
        <div class="row">
		<?php foreach($services as $value){ ?>
             <div class="col-xl-6 col-lg-6 col-md-6">
               <div class="feature-text left-icon mb-40">
                  <div class="feature-icon">
                  <span class="<?php echo $value->icon; ?>" aria-hidden="true"></span>
                  </div>
                  <div class="feature-info">
                  <h5><?php echo $value->title; ?></h5>
                   <p><?php echo $value->tag_line; ?></p>
                   <a class="button icon-color" href="<?php echo $value->link_name1; ?>"><?php echo $value->btn_name1; ?><i class="fa fa-angle-right"></i></a>
                  </div>
               </div>
            </div>
			<?php } ?>
         </div> 
      </div>
      </div>
      </div>
</section>