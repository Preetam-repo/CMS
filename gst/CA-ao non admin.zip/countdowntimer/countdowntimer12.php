<section class="page-section-ptb">
   <div class="container">
   <div class="row">
        <div class="col-lg-12 col-md-12 text-center">
            <div class="countdown countdown-border large">
             <span class="days">00</span>
               <p class="days_ref">days</p>
            </div>
           <div class="countdown countdown-border large">
              <span class="hours">00</span>
              <p class="hours_ref">hours</p>
           </div>
           <div class="countdown countdown-border large">  
              <span class="minutes">00</span>
              <p class="minutes_ref">minutes</p>
             </div>
             <div class="countdown countdown-border large">
              <span class="seconds">00</span>
              <p class="seconds_ref">seconds</p>
             </div>
        </div>
     </div>
     </div>
</section>	 