<section class="page-section-ptb">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12">
            <h4 class="mb-50 text-center">Clients fullwidth </h4>
        </div>
        <div class="col-lg-12 col-md-12">
          <div class="clients-list">
             <div class="owl-carousel" data-nav-dots="false" data-items="8" data-md-items="7" data-sm-items="3" data-xs-items="2" data-xx-items="2">
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/01.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/02.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/03.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/04.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/05.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/06.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/07.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/08.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/09.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/10.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/01.png" alt="">
               </div>
               <div class="item"> 
                  <img class="img-fluid mx-auto" src="images/clients/02.png" alt="">
               </div>
             </div>
          </div>
        </div>
     </div>
   </div>
 </section>