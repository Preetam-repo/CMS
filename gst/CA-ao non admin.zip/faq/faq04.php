<!--=================================
 faq-->

 <section class="faq white-bg page-section-ptb">
  <div class="container">
    <div class="row">
     <div class="col-lg-12 col-md-12 text-center">
        <p class="mb-30">Success isn’t really that difficult. There is a significant portion of the population here in North America, that actually want and need success to be hard! Why? So they then have a built-in excuse when things don’t go their way! Pretty sad situation, to say the least.</p>
        <div class="divider icon mb-30"> <i class="fa fa-bell-o"></i> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <h4>01. Morbi accumsan ipsum velit?</h4>
        <p>Aenean sollicitudin Proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit auctor aliquet. , lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
       <h4>03. Aenean sollicitudin, lorem quis?</h4>
        <p>Nisi elit consequat Proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor,  ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
       <h4>05. Morbi accumsan ipsum velit?</h4>
        <p>Vel velit auctor aliquet Proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh . Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
       <h4>07. Aenean sollicitudin, lorem quis?</h4>
        <p>Gravida Proin lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
      </div>
      <div class="col-sm-6">
        <h4>02. Nam nec tellus a odio tincidunt?</h4>
        <p>Auctor aliquet Proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit . Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
        <h4>04. Nibh vulputate cursus a sit amet?</h4>
        <p>Bibendum auctor proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
        <h4>06. Nam nec tellus a odio tincidunt?</h4>
        <p>Aenean sollicitudin proin gravida lorem ipsum dolor sit amet of Lorem Ipsum nibh vel velit auctor aliquet. lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
        <h4>08. Nibh vulputate cursus a sit amet?</h4>
        <p>Ipsum dolor sit amet Proin gravida lorem  of Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet</p>
       <div class="divider dashed mt-40 mb-40"></div>
      </div>
    </div>
  </div> 
</section>