<?php
error_reporting(0);
$base_url = 'http://suhari.co.in/admin-master/';
$site_url = 'http://localhost/CA-ao/';
$aoId = 1;