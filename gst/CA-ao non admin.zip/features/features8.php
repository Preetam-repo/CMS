<section class="our-services split-section black-bg text-white page-section-ptb">
      <div class="side-background hidden-sm hidden-xs">
        <div class="col-md-6 col-sm-4 img-side img-left">
             <div class="img-holder img-cover parallax" style="background: url(asset/images/bg/06.jpg);">
            </div>
          </div>
      </div>
      <div class="container">        
          <div class="row justify-content-end">
          <div class="col-lg-5">
            <div class="section-title">
          <h6 class="text-white">We're best at</h6>
          <h2 class="text-white">Our key features</h2>
          <p class="text-white">Webster has endless possibilities for creating stunning websites.</p>
       </div>
     <div class="row"> 
           <div class="col-lg-6 col-md-6 col-sm-6">
             <div class="feature-text text-left mb-40">
              <div class="feature-icon">
              <span class="ti-desktop"></span>
              </div>
              <div class="feature-info">
                <h5 class="text-white">Perfect design</h5>
                <p class="text-white">Responsive Lorem Ipsum used since the 1500s is.. </p>
                <a class="button icon-color white" href="#">Read more <i class="fa fa-angle-right"></i></a>
               </div> 
           </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6">
             <div class="feature-text text-left mb-40">
              <div class="feature-icon">
              <span class="ti-headphone"></span>
              </div>
              <div class="feature-info">
                <h5 class="text-white">24/7 Customer support</h5>
                <p class="text-white">Great support quibusdam reproduced enim..</p>
                <a class="button icon-color white" href="#">Read more <i class="fa fa-angle-right"></i></a>
               </div> 
           </div>
          </div>
         </div>
         <div class="row"> 
           <div class="col-lg-6 col-md-6 col-sm-6">
             <div class="feature-text text-left xs-mb-40">
              <div class="feature-icon">
              <span class="ti-panel"></span>
              </div>
              <div class="feature-info">
                <h5 class="text-white">Easy to Customize</h5>
                <p class="text-white">Fully customizable template enim expedita sed..</p>
                <a class="button icon-color white" href="#">Read more <i class="fa fa-angle-right"></i></a>
               </div> 
           </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6">
             <div class="feature-text text-left">
              <div class="feature-icon">
              <span class="ti-shield"></span>
              </div>
              <div class="feature-info">
                <h5 class="text-white">Powerful Performance</h5>
                <p class="text-white">Fast as light Ipsum used since the 1500s.. </p>
                <a class="button icon-color white" href="#">Read more <i class="fa fa-angle-right"></i></a>
               </div> 
           </div>
          </div>
         </div>
          </div>
        </div>
      </div>
</section>