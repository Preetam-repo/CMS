<section class="page-section-ptb theme-bg">
   <div class="container">
       <div class="row ">
        <div class="col-lg-4 col-md-4 col-sm-4 xs-mb-30">
          <div class="feature-text text-center">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-layers-alt text-white"></span>
            </div>
            <h4 class="text-white pt-20">Many Style Available</h4>
            <p class="text-white">Sed quia nesciunt in accusamus necessitatibus modi adipisci officia dolor sit amet, consectetur adipisicing elit. Vero quod conseqt quibusdam </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 xs-mb-30">
          <div class="feature-text text-center">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-image text-white"></span>
            </div>
            <h4 class="text-white pt-20">Revolution Slider</h4>
            <p class="text-white">Vero quod conseqt quibusdam,  sed quia nesciunt in accusamus necessitatibus modi adipisci officia dolor sit amet, consectetur adipisicing elit. </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="feature-text text-center">
            <div class="feature-icon">
            <span aria-hidden="true" class="ti-heart text-white"></span>
            </div>
            <h4 class="text-white pt-20">Blog Options</h4>
            <p class="text-white">Quibusdam sed quia nesciunt in accusamus necessitatibus modi adipisci officia dolor sit amet, consectetur adipisicing elit. Vero quod conseqt</p>
          </div>
        </div>
     </div>
   </div>
</section>