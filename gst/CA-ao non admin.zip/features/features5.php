<section class="white-bg page-section-ptb">
  <div class="container-fluid">
    <div class="row">
     <div class="col-lg-3 col-sm-6 border-right pl-0 pl-sm-40">
       <div class="feature-text p-4">
       <div class="feature-icon">
        <span class="ti-desktop theme-color"></span>
        </div>
        <div class="feature-info">
            <h5>Perfect design</h5>
             <p>Out of box thinking and <span class="theme-color" data-toggle="tooltip" data-placement="top" title="" data-original-title="Won 10+ Awards"> Award-winning</span> web design agency. </p>
         </div>
     </div>
    </div>
    <div class="col-lg-3 col-sm-6 border-right pl-0 pl-sm-40">
       <div class="feature-text p-4">
       <div class="feature-icon">
        <span class="ti-headphone theme-color"></span>
        </div>
        <div class="feature-info">
          <h5>Fast Customer support</h5>
           <p>Our Support Team will do its best to provide the best helpful answer for the issues.</p>
         </div>
     </div>
    </div>
     <div class="col-lg-3 col-sm-6 border-right pl-0 pl-sm-40">
       <div class="feature-text p-4">
       <div class="feature-icon">
        <span class="ti-panel theme-color"></span>
        </div>
        <div class="feature-info">
        <h5>Easy to Customize</h5>
         <p>Webster code is easy and requires no/less programming skills to create a website</p>
       </div>
     </div>
    </div>
    <div class="col-lg-3 col-sm-6">
       <div class="feature-text p-4">
       <div class="feature-icon">
        <span class="ti-shield theme-color"></span>
        </div>
        <div class="feature-info">
            <h5>Powerful Performance</h5>
             <p>High performance, super fast with top page speed & yslow ratings </p>
        </div>
     </div>
    </div>
   </div>
  </div>
</section>