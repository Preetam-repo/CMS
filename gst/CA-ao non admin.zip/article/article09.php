 <section id="blog" class="our-blog page-section-ptb">
  <div class="container-fluid">
    <div class="row">
     <div class="col-lg-12 col-md-12">
         <div class="section-title text-center">
         <h6><?php echo $articleStyle->top_tag_line; ?></h6>
            <h2 class="title-effect"><?php echo $articleStyle->title; ?></h2>
            <p><?php echo $articleStyle->bottom_tag_line; ?></p>
          </div>
       </div>
    </div>
   <div class="row">
   <?php foreach($articles as $value){ ?>
    <div class="col-lg-12 col-ms-12">
     <div class="owl-carousel" data-items="4" data-md-items="3" data-sm-items="2" data-xs-items="1" data-xx-items="1">
      <div class="item">
        <div class="blog-box  blog-1 h-100">        
         <div class="blog-info">
          <span class="post-category"><a href="#"><?php echo $value->category ; ?></a></span>
          <h4> <a href="<?php echo $value->link_name ; ?>"> <?php echo $value->type ; ?></a></h4>
          <p><?php echo $value->summarised_info ; ?></p>
          <span><i class="fa fa-calendar-check-o"></i><?php echo $value->post_date_display ; ?></span>
          </div>  
          <div class="blog-box-img" style="background-image:url(uploads/<?php echo $value->img_link ; ?>);"></div>
        </div>
        </div>
        <?php } ?>
     </div>
    </div>
  </div>
</section>
