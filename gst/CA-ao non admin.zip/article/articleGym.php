 <!--=================================
 Our Blog -->

 <section class="our-blog gray-bg page-section-ptb">
  <div class="container">
    <div class="row">
     <div class="col-lg-12 col-md-12">
         <div class="section-title text-center">
            <h6>Fresh Webster News</h6>
            <h2>Latest Articles</h2>
          </div>
       </div>
    </div>
   <div class="row">
     <div class="col-lg-4 col-md-4 col-sm-12 xs-mb-20">
        <div class="blog-box blog-2 white-bg">        
        <img class="img-fluid full-width" src="demo-categories/gym/images/01.jpg" alt="">
         <div class="blog-info">
          <span class="post-category"><a href="#">Business</a></span>
          <h4> <a href="#"> Does your life lack meaning</a></h4>
          <p>I truly believe Augustine’s words are true.</p>
          <span><i class="fa fa-calendar-check-o"></i> 21 April 2016 </span>
          <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
          </div>            
        </div>
        </div>
     <div class="col-lg-4 col-md-4 col-sm-12 xs-mb-20">
        <div class="blog-box blog-2 white-bg active">        
        <img class="img-fluid full-width" src="demo-categories/gym/images/02.jpg" alt="">
         <div class="blog-info">
          <span class="post-category"><a href="#">Business</a></span>
          <h4> <a href="#"> Supercharge your motivation</a></h4>          
          <p>We also know those epic stories, those modern-day.</p>
          <span><i class="fa fa-calendar-check-o"></i> 21 April 2016 </span>
          <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
          </div>  
        </div>
        </div>
     <div class="col-lg-4 col-md-4 col-sm-12 xs-mb-20">
        <div class="blog-box blog-2 white-bg">
          <img class="img-fluid full-width" src="demo-categories/gym/images/03.jpg" alt="">
          <div class="blog-info">
           <span class="post-category"><a href="#">Business</a></span>
          <h4> <a href="#">  Helen keller a teller </a></h4>         
          <p>I truly believe Augustine’s words are true.</p>
          <span><i class="fa fa-calendar-check-o"></i> 21 April 2016 </span>
          <a class="button icon-color" href="#">Read More<i class="fa fa-angle-right"></i></a>
          </div>
        </div>
      </div>
     </div>
    </div>
 </section>

 <!--=================================
 Our Blog -->