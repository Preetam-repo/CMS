 <!--=================================
Blog --> 

<section class="band-blog page-section-ptb bg-overlay-black-40 parallax" data-jarallax='{"speed": 0.6}' style="background-image: url(demo-categories/band/images/03.jpg);">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12">
     <div class="section-title dark-bg text-center">
            <h6 class="subtitle">Latest Blog</h6>
            <h2 class="title">Our <span class="theme-color"> Blog</span> </h2>
          </div>
       </div>
   </div>
  <div class="row">
     <div class="col-lg-4 col-md-4 sm-mb-20">
        <div class="blog-box blog-1 active">        
         <div class="blog-info">
          <span class="post-category"><a href="#">Business</a></span>
          <h4> <a href="#"> Does your life lack meaning</a></h4>
          <p>I truly believe Augustine’s words are true and if you look Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, qui. at history you know it is true.</p>
          <span><i class="fa fa-user"></i> By Webster</span>
          <span><i class="fa fa-calendar-check-o"></i> 21 April 2018 </span>
          </div>  
          <div class="blog-box-img" style="background-image:url(demo-categories/band/images/blog/01.jpg);"></div>
     
        </div>
        </div>
     <div class="col-lg-4 col-md-4 sm-mb-20">
        <div class="blog-box blog-1 active">        
         <div class="blog-info">
          <span class="post-category"><a href="#">Business</a></span>
          <h4> <a href="#"> Supercharge your motivation</a></h4>          
          <p>We also know those epic stories, those modern-day legends Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, doloremque! surrounding the early failures.</p>
          <span><i class="fa fa-user"></i> By Webster</span>
          <span><i class="fa fa-calendar-check-o"></i> 21 April 2018 </span>
          </div>  
          <div class="blog-box-img" style="background-image:url(demo-categories/band/images/blog/02.jpg);"></div>
        </div>
        </div>
     <div class="col-lg-4 col-md-4">
        <div class="blog-box blog-1 active">
          <div class="blog-info">
           <span class="post-category"><a href="#">Business</a></span>
            <h4> <a href="#">  Helen keller a teller &amp; a seller </a></h4>         
            <p>I truly believe Augustine’s words are true and if you Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, reprehenderit! look at history you know it is true.</p>
            <span><i class="fa fa-user"></i> By Webster</span>
            <span><i class="fa fa-calendar-check-o"></i> 21 April 2018 </span>
            </div>
          <div class="blog-box-img" style="background-image:url(demo-categories/band/images/blog/03.jpg);"></div>
        </div>
      </div>
     </div> 
  </div>
</section>

<!--=================================
Blog --> 