
<section class="page-section-ptb white-bg">
        <div class="container">
           <div class="row">
            <div class="col-lg-12">
              <h4 class="mb-50">Pricing Table </h4>
            </div>
           </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 mb-60">
                   <div class="pricing-table">
                     <div class="pricing-top">
                       <div class="pricing-title">
                         <h3 class="mb-15">Basic</h3>
                         <p>In this package dolor sit amet occaecat cupidatat non proident</p>
                       </div>
                       <div class="pricing-prize">
                         <h2>$49 /<span> month</span> </h2>
                       </div>
                       <div class="pricing-button">
                         <a class="button" href="#">Sign Up</a>
                       </div>
                     </div>
                     <div class="pricing-content">
                       <div class="pricing-table-list">
                            <ul class="list-unstyled">
                                <li> <i class="fa fa-check"></i> 25 Analytics Campaign <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span></li>
                                <li><i class="fa fa-times"></i> Branded Reports <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li><i class="fa fa-check"></i> 1,900 Keywords <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-times"></i> 4 Social Account <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-times"></i>  Phone & Email Support <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                            </ul>
                        </div>
                     </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 mb-60">
                    <div class="pricing-table active">
                     <div class="pricing-top">
                       <div class="pricing-title">
                         <h3 class="mb-15">Standard </h3>
                         <p>Suitable for medium sit amet officia deserunt mollit anim id est laborum</p>
                       </div>
                       <div class="pricing-prize">
                         <h2>$129 /<span> month</span> </h2>
                       </div>
                       <div class="pricing-button">
                         <a class="button" href="#">Sign Up</a>
                       </div>
                     </div>
                     <div class="pricing-content">
                       <div class="pricing-table-list">
                            <ul class="list-unstyled">
                                <li> <i class="fa fa-check"></i> 25 Analytics Campaign <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span></li>
                                <li><i class="fa fa-check"></i> Branded Reports <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li><i class="fa fa-check"></i> 1,900 Keywords <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-check"></i> 4 Social Account <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-check"></i>  Phone & Email Support <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                            </ul>
                        </div>
                     </div>
                  </div> 
                </div>
                <div class="col-lg-4 col-md-4 mb-60">
                   <div class="pricing-table">
                     <div class="pricing-top">
                       <div class="pricing-title">
                         <h3 class="mb-15">Premium</h3>
                         <p>Best for unlimited tempor incididunt ut labore et dolore magna aliqua</p>
                       </div>
                       <div class="pricing-prize">
                         <h2>$99 /<span> month</span> </h2>
                       </div>
                       <div class="pricing-button">
                         <a class="button" href="#">Sign Up</a>
                       </div>
                     </div>
                     <div class="pricing-content">
                       <div class="pricing-table-list">
                            <ul class="list-unstyled">
                                <li> <i class="fa fa-check"></i> 25 Analytics Campaign <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span></li>
                                <li><i class="fa fa-times"></i> Branded Reports <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li><i class="fa fa-check"></i> 1,900 Keywords <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-times"></i> 4 Social Account <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                                <li> <i class="fa fa-check"></i>  Phone & Email Support <span class="tooltip-content float-right" data-placement="top" data-toggle="tooltip" data-original-title="Lorem ipsum dolor sit amet"><i class="fa fa-info"></i></span> </li>
                            </ul>
                        </div>
                     </div>
                  </div> 
                </div>
            </div>
        </div>
</section>            