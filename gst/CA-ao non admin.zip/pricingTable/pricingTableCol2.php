<section class="page-section-ptb white-bg">
        <div class="container">
        <div class="row">
            <div class="col-lg-12">
              <h4 class="mb-50">Pricing Table bootstrap default 2 column </h4>
            </div>
           </div>
          <div class="row">
              <div class="col-lg-6 col-md-6 mb-60">
                <ul class="price">
                  <li class="header">Premium</li>
                  <li class="grey">$ 49.99 / year</li>
                  <li>50GB Storage</li>
                  <li>50 Emails</li>
                  <li>50 Domains</li>
                  <li>5GB Bandwidth</li>
                  <li class="grey"><a href="#" class="button">Sign Up</a></li>
                </ul>
              </div>
              <div class="col-lg-6 col-md-6 mb-60">
                <ul class="price">
                  <li class="header">Premium</li>
                  <li class="grey">$ 49.99 / year</li>
                  <li>50GB Storage</li>
                  <li>50 Emails</li>
                  <li>50 Domains</li>
                  <li>5GB Bandwidth</li>
                  <li class="grey"><a href="#" class="button">Sign Up</a></li>
                </ul>
              </div>
          </div>
            
        </div>
</section>            