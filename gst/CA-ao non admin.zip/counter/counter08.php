<hr class="m-0" />
 
<!--=================================
counter-->

 <section class="page-section-ptb  bg-overlay-black-60 parallax" data-jarallax='{"speed": 0.6}' style="background-image: url(images/bg/02.jpg);">
  <div class="container">
    <div class="row">
        <div class="col-lg-3 col-sm-6 sm-mb-30">
        <div class="counter left-icon text-white">
          <span class="icon ti-user theme-color" aria-hidden="true"></span>
          <span class="timer" data-to="4905" data-speed="10000">4905</span>
          <label>ORDERED COFFEE'S</label>
        </div>
      </div>
       <div class="col-lg-3 col-sm-6 sm-mb-30">
        <div class="counter left-icon text-white">
         <span class="icon ti-help-alt theme-color" aria-hidden="true"></span>
          <span class="timer" data-to="3750" data-speed="10000">3750</span>
          <label>QUESTIONS ANSWERED</label>
        </div>
      </div>
       <div class="col-lg-3 col-sm-6 xs-mb-30">
        <div class="counter left-icon text-white">
          <span class="icon ti-check-box theme-color" aria-hidden="true"></span>
          <span class="timer" data-to="4782" data-speed="10000">4782</span>
          <label>COMPLETED PROJECTS</label>
        </div>
      </div>
       <div class="col-lg-3 col-sm-6">
        <div class="counter left-icon text-white">
          <span class="icon ti-face-smile theme-color" aria-hidden="true"></span>
          <span class="timer" data-to="3237" data-speed="10000">3237</span>
          <label>HAPPY CLIENTS</label>
        </div>
      </div>
    </div>
  </div>
</section>

<!--=================================
counter-->